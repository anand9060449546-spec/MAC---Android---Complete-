package com.mac.companion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatLine(val fromMac: Boolean, val text: String, val timestamp: Long = System.currentTimeMillis())

/** Small persistent chat history using Android SharedPreferences. Not encrypted. */
class ChatStore(context: Context) {
    private val prefs = context.getSharedPreferences("mac_chat_store", Context.MODE_PRIVATE)
    fun load(): List<ChatLine> {
        val raw = prefs.getString("history", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatLine(o.optBoolean("mac"), o.optString("text"), o.optLong("timestamp"))
            }.takeLast(100)
        } catch (_: Exception) { emptyList() }
    }
    fun save(lines: List<ChatLine>) {
        val arr = JSONArray()
        lines.takeLast(100).forEach { line ->
            arr.put(JSONObject().put("mac", line.fromMac).put("text", line.text).put("timestamp", line.timestamp))
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }
    fun clear() { prefs.edit().remove("history").apply() }
}
