package com.mac.companion

/** Pure command classifier: easy to test and deliberately does not execute actions. */
enum class CommandType { YOUTUBE, SETTINGS, SEARCH, TIMER, NOTE, CALENDAR, MAPS, CALL, SMS, UNKNOWN }
data class ParsedCommand(val type: CommandType, val argument: String = "")

object CommandParser {
    fun parse(raw: String): ParsedCommand {
        val s = raw.trim()
        val lower = s.lowercase()
        return when {
            listOf("open youtube", "youtube kholo", "यूट्यूब खोलो").any(lower::contains) ->
                ParsedCommand(CommandType.YOUTUBE)
            listOf("open settings", "settings kholo", "सेटिंग खोलो").any(lower::contains) ->
                ParsedCommand(CommandType.SETTINGS)
            lower.startsWith("search ") -> ParsedCommand(CommandType.SEARCH, s.drop(7).trim())
            lower.startsWith("google ") -> ParsedCommand(CommandType.SEARCH, s.drop(7).trim())
            listOf("timer", "alarm", "timer lagao", "टाइमर लगाओ").any(lower::contains) ->
                ParsedCommand(CommandType.TIMER)
            lower.startsWith("note ") || lower.startsWith("notes ") ->
                ParsedCommand(CommandType.NOTE, s.substringAfter(' ').trim())
            lower.startsWith("calendar ") || lower.startsWith("event ") ->
                ParsedCommand(CommandType.CALENDAR, s.substringAfter(' ').trim())
            lower.startsWith("navigate ") || lower.startsWith("directions to ") || lower.startsWith("map ") ->
                ParsedCommand(CommandType.MAPS, s.substringAfter(' ').trim())
            lower.startsWith("call ") -> ParsedCommand(CommandType.CALL, s.drop(5).trim())
            lower.startsWith("sms ") || lower.startsWith("message ") ->
                ParsedCommand(CommandType.SMS, s.substringAfter(' ').trim())
            else -> ParsedCommand(CommandType.UNKNOWN)
        }
    }
}
