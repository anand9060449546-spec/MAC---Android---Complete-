package com.mac.companion

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(50, TimeUnit.SECONDS)
        .build()

    fun chat(url: String, lines: List<ChatLine>): String {
        return try {
            val messages = JSONArray()
            lines.takeLast(20).forEach { line ->
                messages.put(JSONObject()
                    .put("role", if (line.fromMac) "model" else "user")
                    .put("text", line.text.take(4000)))
            }
            val body = JSONObject().put("messages", messages).toString()
            val request = Request.Builder().url(url.trim()).post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) "AI server error (${response.code}). Backend aur API key check karo."
                else JSONObject(text).optString("reply").ifBlank { "Sorry dost, MAC ko jawab nahi mila." }
            }
        } catch (_: java.net.UnknownHostException) {
            "Internet ya backend connection nahi mil raha. Local commands abhi bhi kaam kar sakte hain."
        } catch (_: java.net.SocketTimeoutException) {
            "AI server ne time par reply nahi diya. Thodi der baad try karo."
        } catch (_: Exception) {
            "MAC AI server se connect nahi ho pa raha. Settings mein backend URL check karo."
        }
    }
}
