package com.mac.companion

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.Locale

private val Navy = Color(0xFF050B18)
private val Panel = Color(0xFF0C192B)
private val Cyan = Color(0xFF42DDF5)
private val Muted = Color(0xFF9AB7CC)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MacApp(this) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                tts?.language = Locale.US
        }
    }
    fun speak(text: String) {
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "mac_reply")
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun MacApp(activity: MainActivity) {
    val context = activity
    val scope = rememberCoroutineScope()
    val store = remember { ChatStore(context) }
    val history = remember { mutableStateListOf<ChatLine>().apply {
        addAll(store.load())
        if (isEmpty()) add(ChatLine(true, "Namaste, dost! Main MAC hoon. Baat karein ya koi phone command chalayein?"))
    } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("READY • LOCAL COMMANDS AVAILABLE") }
    var apiUrl by remember { mutableStateOf("http://10.0.2.2:3000/chat") }
    var showSettings by remember { mutableStateOf(false) }
    var pendingConfirmation by remember { mutableStateOf<PendingAction?>(null) }
    var torchOn by remember { mutableStateOf(false) }
    var ttsEnabled by remember { mutableStateOf(true) }

    val pulse = rememberInfiniteTransition(label = "core")
    val glow by pulse.animateFloat(0.3f, 0.9f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "glow")

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
        else Toast.makeText(context, "Speech samajh nahi aayi. Dobara try karo.", Toast.LENGTH_SHORT).show()
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeech(context, speechLauncher)
        else Toast.makeText(context, "Microphone permission denied.", Toast.LENGTH_SHORT).show()
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) toggleTorch(context, torchOn) { torchOn = it }
        else Toast.makeText(context, "Flashlight ke liye camera permission chahiye.", Toast.LENGTH_SHORT).show()
    }

    fun addLine(line: ChatLine) {
        history.add(line)
        while (history.size > 100) history.removeAt(0)
        store.save(history.toList())
    }
    fun sendPrompt() {
        val prompt = input.trim()
        if (prompt.isEmpty() || busy) return
        input = ""
        addLine(ChatLine(false, prompt))
        when (val command = CommandParser.parse(prompt)) {
            is ParsedCommand -> when (command.type) {
                CommandType.YOUTUBE -> { openYoutube(context); addLine(ChatLine(true, "YouTube kholne ki koshish ki, dost.")) }
                CommandType.SETTINGS -> { safeStart(context, Intent(android.provider.Settings.ACTION_SETTINGS)); addLine(ChatLine(true, "Settings screen khol di.")) }
                CommandType.SEARCH -> {
                    if (command.argument.isBlank()) addLine(ChatLine(true, "Search ke liye bolo: search Pune weather"))
                    else { safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(command.argument)))); addLine(ChatLine(true, "Web search khol raha hoon: ${command.argument}")) }
                }
                CommandType.TIMER -> {
                    val intent = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, 300)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "MAC timer")
                    pendingConfirmation = PendingAction("Open 5-minute timer", "Clock app mein 5-minute timer setup screen kholun?", intent)
                }
                CommandType.NOTE -> {
                    if (command.argument.isBlank()) addLine(ChatLine(true, "Note save karne ke liye likho: note doodh lena"))
                    else {
                        val notes = context.getSharedPreferences("mac_notes", Context.MODE_PRIVATE)
                        val current = notes.getString("notes", "").orEmpty()
                        notes.edit().putString("notes", (current + "\n• " + command.argument).trim()).apply()
                        addLine(ChatLine(true, "Note phone par locally save kar diya: ${command.argument}"))
                    }
                }
                CommandType.CALENDAR -> {
                    if (command.argument.isBlank()) addLine(ChatLine(true, "Event ka title do: calendar Dentist appointment"))
                    else {
                        val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                            .putExtra(CalendarContract.Events.TITLE, command.argument)
                            .putExtra(CalendarContract.Events.DESCRIPTION, "Created with MAC")
                        pendingConfirmation = PendingAction("Create calendar event", "Calendar app mein '${command.argument}' event draft kholun?", intent)
                    }
                }
                CommandType.MAPS -> {
                    val destination = command.argument.ifBlank { prompt.substringAfter(' ').trim() }
                    if (destination.isBlank()) addLine(ChatLine(true, "Bolo: navigate to Pune station"))
                    else {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination)))
                            .setPackage("com.google.android.apps.maps")
                        pendingConfirmation = PendingAction("Open navigation", "Maps mein $destination ke directions kholun?", intent)
                    }
                }
                CommandType.CALL -> {
                    val number = command.argument
                    if (number.isBlank()) addLine(ChatLine(true, "Bolo: call 9876543210"))
                    else pendingConfirmation = PendingAction("Prepare call", "$number ke liye dialer kholun? Call tum khud confirm karoge.", Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
                }
                CommandType.SMS -> {
                    val body = command.argument
                    if (body.isBlank()) addLine(ChatLine(true, "Bolo: message 9876543210 Hello"))
                    else {
                        val pieces = body.split(" ", limit = 2)
                        val recipient = pieces.first()
                        val message = pieces.getOrElse(1) { "" }
                        val uri = Uri.parse("smsto:" + Uri.encode(recipient))
                        val intent = Intent(Intent.ACTION_SENDTO, uri).putExtra("sms_body", message)
                        pendingConfirmation = PendingAction("Prepare message", "Messaging app mein recipient aur message review karne ke liye kholun? MAC ise khud send nahi karega.", intent)
                    }
                }
                CommandType.UNKNOWN -> {
                    busy = true; status = "ASKING GEMINI…"
                    scope.launch {
                        val answer = withContext(Dispatchers.IO) { GeminiClient.chat(apiUrl, history.toList()) }
                        addLine(ChatLine(true, answer))
                        if (ttsEnabled) activity.speak(answer)
                        busy = false; status = "READY • CHAT SAVED LOCALLY"
                    }
                }
            }
        }
        store.save(history.toList())
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Panel, onSurface = Color.White, onBackground = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071629), Navy, Color(0xFF02050B))))
                .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("MAC", fontSize = 29.sp, fontWeight = FontWeight.Black, color = Cyan)
                    Text("MY ADVANCED COMPANION", fontSize = 9.sp, color = Muted, letterSpacing = 2.sp)
                }
                TextButton(onClick = { showSettings = !showSettings }) { Text("⚙ SETTINGS", color = Cyan) }
            }
            if (showSettings) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Gemini backend URL", color = Cyan, fontWeight = FontWeight.Bold)
                        BasicTextField(apiUrl, { apiUrl = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp))
                        Text("Emulator: http://10.0.2.2:3000/chat. Physical phone: computer LAN IP. Use HTTPS in production.",
                            color = Muted, fontSize = 11.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = ttsEnabled, onCheckedChange = { ttsEnabled = it })
                            Text("Speak AI replies", color = Color.White)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { history.clear(); store.clear(); addLine(ChatLine(true, "Chat history clear kar di.")) }) {
                                Text("Clear history", color = Cyan)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
            Box(Modifier.fillMaxWidth().height(145.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(128.dp).border(1.dp, Cyan.copy(alpha = glow), CircleShape).padding(10.dp)
                    .border(2.dp, Cyan.copy(alpha = glow), CircleShape).padding(10.dp)
                    .background(Cyan.copy(alpha = 0.07f), CircleShape), contentAlignment = Alignment.Center) {
                    Text("M", color = Cyan, fontSize = 48.sp, fontWeight = FontWeight.ExtraLight)
                }
                Text(status, Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp), color = Muted, fontSize = 9.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                QuickButton("▶ YouTube", Modifier.weight(1f)) { openYoutube(context) }
                QuickButton("⚡ Torch", Modifier.weight(1f)) {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                        toggleTorch(context, !torchOn) { torchOn = it }
                    else cameraPermission.launch(Manifest.permission.CAMERA)
                }
                QuickButton("⏰ Timer", Modifier.weight(1f)) {
                    pendingConfirmation = PendingAction("Open timer", "Clock app mein 5-minute timer setup screen kholun?",
                        Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, 300).putExtra(AlarmClock.EXTRA_MESSAGE, "MAC timer"))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("CONVERSATION • LAST 100 MESSAGES SAVED", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(5.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(history) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromMac) Arrangement.Start else Arrangement.End) {
                        Surface(color = if (line.fromMac) Panel else Color(0xFF103348), shape = RoundedCornerShape(15.dp)) {
                            Text(line.text, Modifier.widthIn(max = 300.dp).padding(11.dp), color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                        Toast.makeText(context, "Device speech recognition unavailable.", Toast.LENGTH_LONG).show()
                    } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        launchSpeech(context, speechLauncher)
                    } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("🎙", fontSize = 22.sp) }
                BasicTextField(input, { input = it }, Modifier.weight(1f)
                    .background(Panel, RoundedCornerShape(22.dp)).padding(horizontal = 14.dp, vertical = 13.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                    decorationBox = { inner -> Box { if (input.isBlank()) Text("MAC se baat karo…", color = Muted); inner() } })
                Spacer(Modifier.width(7.dp))
                Button(enabled = !busy && input.isNotBlank(), onClick = { sendPrompt() }) { Text(if (busy) "…" else "SEND") }
            }
        }
        pendingConfirmation?.let { action ->
            AlertDialog(
                onDismissRequest = { pendingConfirmation = null },
                title = { Text(action.title) },
                text = { Text(action.message) },
                confirmButton = {
                    TextButton(onClick = {
                        pendingConfirmation = null
                        try {
                            context.startActivity(action.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            addLine(ChatLine(true, "Requested screen open kar di. Final action app mein review/confirm karo."))
                        } catch (_: Exception) {
                            addLine(ChatLine(true, "Is device par ye action available nahi hai ya required app install nahi hai."))
                        }
                    }) { Text("CONTINUE") }
                },
                dismissButton = { TextButton(onClick = { pendingConfirmation = null }) { Text("CANCEL") } }
            )
        }
    }
}

data class PendingAction(val title: String, val message: String, val intent: Intent)

fun launchSpeech(context: Context, launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "MAC ko boliye")
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
    }
    try { launcher.launch(intent) }
    catch (_: Exception) { Toast.makeText(context, "Voice input unavailable; type your command.", Toast.LENGTH_SHORT).show() }
}

fun safeStart(context: Context, intent: Intent) {
    try { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { Toast.makeText(context, "Required app/action unavailable.", Toast.LENGTH_SHORT).show() }
}

fun openYoutube(context: Context) {
    val launch = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
    if (launch != null) safeStart(context, launch)
    else safeStart(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
}

fun toggleTorch(context: Context, enabled: Boolean, result: (Boolean) -> Unit) {
    try {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull { camera ->
            manager.getCameraCharacteristics(camera).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) {
            Toast.makeText(context, "Flashlight not available on this device.", Toast.LENGTH_SHORT).show()
            result(false)
        } else {
            manager.setTorchMode(id, enabled)
            result(enabled)
        }
    } catch (_: Exception) {
        Toast.makeText(context, "Could not control flashlight. Check camera permission.", Toast.LENGTH_SHORT).show()
        result(false)
    }
}
