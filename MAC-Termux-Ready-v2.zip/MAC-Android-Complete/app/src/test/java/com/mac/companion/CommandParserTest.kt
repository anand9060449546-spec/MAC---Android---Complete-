package com.mac.companion

import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    @Test fun recognizesYoutubeInEnglish() {
        assertEquals(CommandType.YOUTUBE, CommandParser.parse("open youtube").type)
    }
    @Test fun recognizesSettingsInHinglish() {
        assertEquals(CommandType.SETTINGS, CommandParser.parse("settings kholo").type)
    }
    @Test fun extractsSearchQuery() {
        val parsed = CommandParser.parse("search Pune weather")
        assertEquals(CommandType.SEARCH, parsed.type)
        assertEquals("Pune weather", parsed.argument)
    }
    @Test fun extractsNote() {
        val parsed = CommandParser.parse("note buy milk")
        assertEquals(CommandType.NOTE, parsed.type)
        assertEquals("buy milk", parsed.argument)
    }
    @Test fun doesNotExecuteUnknownAsCommand() {
        assertEquals(CommandType.UNKNOWN, CommandParser.parse("tell me a joke").type)
    }
}
