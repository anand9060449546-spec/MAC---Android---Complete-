# MAC — My Advanced Companion AI (Android starter v1.1)

Native Android starter using Kotlin, Jetpack Compose, a Gemini server backend, system speech recognition, TextToSpeech, locally persisted chat, and safe intent-based phone actions.

## Compatibility
- `minSdk 26` (Android 8.0), `compileSdk 36`, `targetSdk 35`
- JDK 17
- Android Studio with Android SDK Platform 36
- Node.js 20+ for the backend
- This source archive has **not been compiled or device-tested in this environment**. It is not an APK and is not a guarantee of a clean build.

## Open the project
1. Download and extract the ZIP on a computer.
2. Android Studio → **Open** → select the extracted `MAC-Android-Complete` folder.
3. Install Android SDK Platform 36 if prompted.
4. Wait for Gradle sync.
5. Run the `app` configuration on an emulator or Android phone with USB debugging.

## Run the Gemini backend
1. Get a Gemini API key from Google AI Studio.
2. Open a terminal in `backend/`.
3. Run `npm install`.
4. Set the API key in the terminal environment:
   - macOS/Linux: `export GEMINI_API_KEY="YOUR_KEY"`
   - Windows PowerShell: `$env:GEMINI_API_KEY="YOUR_KEY"`
5. Start: `npm start`
6. Check `http://localhost:3000/health`.

Do not commit the key or embed it in Android. The app defaults to `http://10.0.2.2:3000/chat` for the Android emulator. On a physical phone, set the URL in MAC Settings to `http://YOUR_COMPUTER_LAN_IP:3000/chat`, with phone and computer on the same trusted Wi-Fi. This development HTTP configuration is for local testing only. Production must use HTTPS, authentication, rate limiting, and access controls.

The Android manifest allows cleartext HTTP to make local development easier. Before release, change `android:usesCleartextTraffic` to `false` and deploy the backend behind HTTPS.

## Build APK
Android Studio → **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Wait for the success notification and select **Locate**. The usual debug path is `app/build/outputs/apk/debug/app-debug.apk`.

Optional command line after configuring Gradle wrapper:
```bash
./gradlew testDebugUnitTest assembleDebug
```
Windows:
```powershell
.\gradlew.bat testDebugUnitTest assembleDebug
```
A Gradle wrapper is not included. Android Studio can manage Gradle; if you want command-line builds, generate the wrapper using a compatible Gradle installation.

## Current features in this source
- Compose dark/cyan sci-fi UI and animated core.
- Actual Android speech recognition activity result returned into the input field, after runtime microphone permission.
- TextToSpeech responses, with Hindi locale preference and fallback.
- Gemini backend call with recent chat context.
- Persistent local chat history (up to 100 messages) and clear-history control using SharedPreferences.
- Local notes using SharedPreferences (`note buy milk`).
- App/settings launch, Google search, timer setup screen, calendar event draft, Maps navigation intent, dialer and SMS composer intent.
- Confirmation dialog before opening timer, calendar, navigation, dialer or message composer.
- Flashlight toggle attempt with runtime camera permission.
- JUnit command parser tests.

## Command examples
- `open youtube`
- `settings kholo`
- `search Pune weather`
- `timer`
- `note buy milk`
- `calendar Dentist appointment`
- `navigate to Pune railway station`
- `call 9876543210` → opens dialer after in-app confirmation; does not place call.
- `message 9876543210 Hello` → opens messaging composer after in-app confirmation; user reviews and sends manually.

## Explicitly unfinished / constrained
- **No wake word:** “Hey MAC” always-on background listening is not implemented. Android background microphone and OEM battery rules make this nontrivial; push-to-talk is implemented.
- **No notification reading:** requires Notification Listener access, user-granted separately in system settings, and a dedicated listener service.
- **No scheduled reminders or alarm parsing:** the timer command opens a 5-minute timer setup screen. It does not silently schedule a custom duration. Calendar command opens an event draft; the user must save it in the calendar app.
- **No direct call or SMS sending:** only opens dialer/composer after confirmation. MAC never silently sends.
- **Notes are plain local preferences:** no edit/search/delete UI, no encryption, and no cloud sync.
- **Chat memory is local conversation history only:** it does not infer a profile or maintain long-term semantic memory. SharedPreferences is not encrypted; do not store secrets or sensitive data.
- **Backend security is development-level:** no authentication, rate limiting, user accounts, request quotas, or production CORS policy. Add those before deployment.
- **Model availability can vary:** change `GEMINI_MODEL` to a currently supported model for your account/region.
- **Speech quality/locale varies** by installed recognition service and TTS voice data.
- **No verified APK:** compile, test, and review on your own SDK/device before distribution.

## Test plan
1. `./gradlew testDebugUnitTest` — command parser tests.
2. Run without backend; local commands should still work and AI should show a connection message.
3. Run backend and ask MAC a Hindi/Hinglish question.
4. Use microphone, grant permission, speak, check text appears, then press Send.
5. Deny microphone and verify typing still works.
6. Test torch on a device with flash; test on emulator/no-flash device.
7. Try note, timer, calendar, Maps, call, and message; cancel each confirmation and ensure no intent opens.
8. Test chat persistence by force-closing and reopening the app.
9. Test Clear history and verify the chat is reset.
10. Before release, disable cleartext traffic, use HTTPS, add backend auth/rate limits, test on multiple Android versions, and review privacy disclosures.

## Architecture summary
- `MainActivity.kt`: Compose screen, permission launchers, intent-based actions, confirmation dialogs.
- `CommandParser.kt`: pure command parser with unit tests.
- `ChatStore.kt`: local conversation persistence.
- `GeminiClient.kt`: Android HTTP client to the backend.
- `backend/server.js`: API key remains server-side.

## Termux on Android phone (Hindi)

**Termux ka kaam:** ZIP extract karna aur Node.js backend chalana. Native Android APK ko Termux par seedha build karna aksar mushkil hota hai, kyunki Android SDK/build-tools ka setup alag hai. Is ZIP mein GitHub Actions workflow bhi hai jo cloud mein APK banata hai.

1. Termux ko F-Droid ya uske official GitHub release se install karo.
2. ZIP ko phone ke Download folder mein rakho. Termux mein:

```bash
termux-setup-storage
pkg update -y
pkg install -y unzip
cd ~/storage/downloads
unzip MAC-Android-Complete.zip -d MAC
cd MAC
bash scripts/termux-setup.sh
```

3. Gemini API key ko environment variable mein set karo (apni key kisi ko share mat karna):

```bash
export GEMINI_API_KEY="PASTE_YOUR_GEMINI_API_KEY_HERE"
bash scripts/termux-run-backend.sh
```

4. Backend default port `3000` par chalta hai. Phone par app ko backend se connect karne ke liye app ke code mein backend URL ko `http://127.0.0.1:3000/chat` set karna hoga agar backend aur app ek hi phone par hain. Dhyan rahe Android app ka localhost aur backend process ka localhost same phone par hoga; lekin app ke network security settings mein cleartext HTTP allowed hona chahiye. Public deployment ke liye HTTPS use karo.

## APK build karne ka aasaan raasta (GitHub Actions)

1. ZIP ko extract karo.
2. GitHub par naya repository banao aur is folder ki files upload karo (root mein `settings.gradle.kts` aur `app/` dikhne chahiye).
3. Repository ke **Actions** tab mein `Build MAC Android APK` workflow chalao, ya `main`/`master` branch par push karo.
4. Build successful ho to workflow run ke **Artifacts** section se `MAC-debug-APK` download karo. ZIP ke andar APK pehle se nahi hai; APK workflow build karega.

**Status:** source project aur workflow provided hain, lekin is environment mein Android build run nahi kiya gaya. Agar build fail ho, Actions ke error log ke saath bhejo taaki fix kiya ja sake. API key ko Android source code mein mat daalna; backend mein environment variable ke roop mein rakho.
