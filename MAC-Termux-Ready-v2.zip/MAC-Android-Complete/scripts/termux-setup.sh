#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg upgrade -y
pkg install -y nodejs-lts git unzip nano
cd "$(dirname "$0")/../backend"
npm install
printf '\nMAC backend dependencies installed.\n'
printf 'Next: export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"\n'
printf 'Then run: bash ../scripts/termux-run-backend.sh\n'
