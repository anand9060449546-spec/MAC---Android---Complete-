#!/data/data/com.termux/files/usr/bin/bash
set -e
if [ -z "${GEMINI_API_KEY:-}" ]; then
  echo 'Missing GEMINI_API_KEY. Run: export GEMINI_API_KEY="YOUR_GEMINI_API_KEY"'
  exit 1
fi
cd "$(dirname "$0")/../backend"
npm start
