import express from "express";
import { GoogleGenAI } from "@google/genai";

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "64kb" }));

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("Missing GEMINI_API_KEY environment variable.");
  process.exit(1);
}
const ai = new GoogleGenAI({ apiKey });

app.get("/health", (_req, res) => res.json({ ok: true, service: "MAC backend" }));

app.post("/chat", async (req, res) => {
  try {
    const incoming = req.body?.messages;
    if (!Array.isArray(incoming) || incoming.length === 0) {
      return res.status(400).json({ error: "messages array required" });
    }
    const messages = incoming.slice(-20).map(m => ({
      role: m?.role === "model" ? "model" : "user",
      text: String(m?.text ?? "").slice(0, 4000)
    }));
    const contents = messages.map(m => `${m.role === "model" ? "MAC" : "User"}: ${m.text}`).join("\n");
    const result = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-2.5-flash",
      contents,
      config: {
        systemInstruction: [
          "You are MAC (My Advanced Companion AI), a friendly, witty and respectful companion.",
          "Speak naturally in Hindi, Hinglish, or English according to the user.",
          "Be useful, honest and concise by default. Never claim you performed a phone action unless the Android app confirms it.",
          "Ask the user to confirm consequential actions. Do not claim access to private device data."
        ].join(" ")
      }
    });
    return res.json({ reply: result.text || "Sorry dost, is baar jawab nahi bana paaya." });
  } catch (error) {
    console.error("Gemini request failed:", error?.message || "unknown error");
    return res.status(502).json({ error: "AI service temporarily unavailable." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`MAC backend listening on ${port}`));
